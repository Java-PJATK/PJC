#include <iostream>
using namespace std;

int main() {
    char nap1[100], nap2[100];

    cout << "\nEnter two strings separated by spaces: ";
    cin  >>  nap1 >> nap2;
    cout << "\nString 1: " << nap1 << endl;
    cout <<   "String 2: " << nap2 << endl << endl;
}
