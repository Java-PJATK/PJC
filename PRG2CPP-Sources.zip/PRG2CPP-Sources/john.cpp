#include <iostream>
#include <string>
using namespace std;

int main() {
    double weight = 76.5;
    int    height = 182;
    string name   = "John";
    cout << name   << " weighs "  << weight << " kg and is "
         << height << " cm tall." << endl;
}
