#include <iostream>
using namespace std;

/*
    We always start with
    program Hello, World!
 */

int main() { // Comments as in Java
    cout << "Hello, World" << endl;
}
