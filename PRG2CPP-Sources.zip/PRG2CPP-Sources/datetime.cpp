#include <iostream>
using namespace std;

int main() {
    cout << "File:     " << __FILE__     << endl
         << "Date:     " << __DATE__     << endl
         << "Line:     " << __LINE__     << endl
         << "Time:     " << __TIME__     << endl
         << "Function: " << __FUNCTION__ << endl;
}
