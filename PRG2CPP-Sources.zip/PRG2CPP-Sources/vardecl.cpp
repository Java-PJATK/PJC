#include <iostream>
using namespace std;

int main() {
    int k1;
    int k2(1);
    int k3{};
    int k4{1};
    int n=1, m = n, i{1}, j{i};
}
