#ifndef _SORTINTE_H
#define _SORTINTE_H

// comments...

void sort(int[],int);
void writarr(const int[],int);
#endif
